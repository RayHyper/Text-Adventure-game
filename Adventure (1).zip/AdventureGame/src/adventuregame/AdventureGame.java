/*
 * ICSU 5B
 * Raymond Lam
 * April 18th, 2021
 * Hurricane of Silence Game
 */
package adventuregame;
import java.util.Scanner;
import java.util.Random;
public class AdventureGame {

    public static void main(String[] args) {
        //Objects
        Scanner Input = new Scanner(System.in);
        Random random = new Random();
        
        //Variable
        String name;
        String playAgain;
        int choice;
        boolean gameRunning = true;
        
        //Starting screen
        System.out.println("---------------Hurricane of Silence-----------");
        System.out.print("Please enter your name: ");
        name = Input.nextLine();
        System.out.println("Welcome " + name + " to the game Hurricane of Silence!");
        System.out.println("Press \"ENTER\" to start");
        Input.nextLine();
        while(gameRunning == true)
        {
        System.out.println("!!!--------------The Beginnings-------!!!");
        System.out.println("You are a Canadian traveler that evacuated from a hurricane.");
        System.out.println("The hurricane had ripped through your home town and cause a lot of damage.");
        System.out.println("You get back and see your town was destroyed.");
        System.out.println("You are determined to get back home.");
        System.out.println("Press \"ENTER\" to continue..");
        Input.nextLine();
        System.out.println("Choose where you want to start your adventure.");
        System.out.println("[Enter the number]");
        System.out.println("\t[1] To the right there is some mountains");
        System.out.println("\t[2] In front there is a river");
        System.out.println("\t[3] To the left there is a forest");
        System.out.print(">"); 
        choice = Input.nextInt();
        
        //Mountains
        if(choice == 1)
        {
            System.out.println("\nYou go to the mountains.");
            System.out.println("There is a huge mountain with a ravine.");
            System.out.println("You need to get to the other side.");
            System.out.println("\t[1] Try to jump to the other side");
            System.out.println("\t[2] Take the longer way and walk around");
            System.out.print(">");
            choice = Input.nextInt();
                //Jump
                if(choice == 1)
                {
                    System.out.println("\nYou fall into a huge pit...");
                    System.out.println("You survived the fall but are stuck.");
                    System.out.println("It's getting dark and you need to get out.");
                    System.out.println("\t[1] Try to climb out");
                    System.out.println("\t[2] Wait and sleep for the night");
                    System.out.print(">");
                    choice = Input.nextInt();
                        if(choice == 1)
                        {
                            System.out.println("\nYou do a running jump!");
                            System.out.println("You manage to pull yourself out!");
                            System.out.println("You keep walking and there is a river.");
                            System.out.println("\t[1] Think of an idea");
                            System.out.println("\t[2] Try to swim");
                            System.out.print(">");
                            choice = Input.nextInt();
                                if(choice == 1)
                                {
                                    System.out.println("\nYou look around for some materials.");
                                    System.out.println("You find some wood and a broken raft.");
                                    System.out.println("The river is flowing very fast.");
                                    System.out.println("\t[1] Make a raft");
                                    System.out.println("\t[2] Make a bridge");
                                    System.out.print(">");
                                    choice = Input.nextInt();
                                        if(choice == 1)
                                        {
                                            System.out.println("\nYou make a raft.");
                                            System.out.println("You paddle across the river.");                                            
                                        }
                                        else if(choice == 2)
                                        {
                                            System.out.println("\nYou make a bridge out of wood.");
                                            System.out.println("You lay the plank across and walk carefully.");
                                        }
                                }
                                else if(choice == 2)
                                {
                                    System.out.println("\nThe current is too fast!");
                                    System.out.println("You blackout and wake up. You are alive!");                                                                      
                                }
                                System.out.println("You made it across the river!");
                                System.out.println("You keep going and find some abandoned houses.");
                                System.out.println("\t[1] Explore the houses");
                                System.out.println("\t[2] Keep walking");
                                System.out.print(">");
                                choice = Input.nextInt();
                                    if(choice == 1)
                                    {
                                        System.out.println("\nYou go in one of the houses.");
                                        System.out.println("You search the house to see if anybody is here.");
                                        System.out.println("Press \"ENTER\" to continue..");
                                        Input.nextLine();
                                        Input.nextLine();
                                        System.out.println("Suddenly you hear a sound in the basement.");
                                        System.out.println("\t[1] Go look");
                                        System.out.println("\t[2] Go out of the house");
                                        System.out.print(">");
                                        choice = Input.nextInt();
                                            if(choice == 1)
                                            {
                                                System.out.println("\nYou go down the basement stairs.");
                                                System.out.println("Suddenly you feel a chill down your spine.");
                                                System.out.println("You have a very uneasy feeling.");
                                                System.out.println("\t[1] Keep going");
                                                System.out.println("\t[2] RUN");
                                                System.out.print(">");
                                                choice = Input.nextInt();
                                                    if(choice == 1)
                                                    {
                                                        System.out.println("\nYou keep going furthur into the basement.");
                                                        System.out.println("It's pitch black dark.");
                                                        System.out.println("Suddenly you see a black figure.");
                                                        System.out.println("Press \"ENTER\" to continue..");
                                                        Input.nextLine();
                                                        Input.nextLine();
                                                        System.out.println("BANG!");
                                                        System.out.println("You try to run but couldn't.");
                                                        System.out.println("You are DEAD.");
                                                    }
                                                    else if(choice == 2)
                                                    {
                                                        System.out.println("\nYou RUN out of the abandoned house.");
                                                        System.out.println("You keep walking and see a familiar sight.");
                                                        System.out.println("You let go a sigh of relief...");
                                                        System.out.println("Press \"ENTER\" to continue..");
                                                        Input.nextLine();
                                                        Input.nextLine();
                                                        System.out.println("YOU MADE IT HOME!!!");
                                                    }
                                            }
                                            else if(choice == 2)
                                            {
                                                System.out.println("\nYou walk out of the abandoned house.");
                                                System.out.println("You keep walking and see a familiar sight.");
                                                System.out.println("You let go a sigh of relief...");
                                                System.out.println("Press \"ENTER\" to continue..");
                                                Input.nextLine();
                                                Input.nextLine();
                                                System.out.println("YOU MADE IT HOME!!!");
                                            }
                                    }
                                    else if(choice == 2)
                                    {
                                        System.out.println("\nYou keep walking and see a familiar sight.");
                                        System.out.println("Out of all the houses, there was just one standing.");
                                        System.out.println("You let go a sigh of relief...");
                                        System.out.println("Press \"ENTER\" to continue..");
                                        Input.nextLine();
                                        Input.nextLine();
                                        System.out.println("YOU MADE IT HOME!!!");
                                    }
                        }
                        else if(choice == 2)
                        {
                            System.out.println("\nYou wake up and are still in the pit.");
                            System.out.println("You haven't had water or food.");
                            System.out.println("It's getting dark.");
                            System.out.println("\t[1] Sleep");
                            System.out.println("\t[2] Try to climb out");
                            System.out.print(">");
                            choice = Input.nextInt();
                                if(choice == 1)
                                {
                                    System.out.println("\nMany nights go by without food or water.");
                                    System.out.println("You are DEAD.");
                                }
                                else if(choice == 2)
                                {
                                    System.out.println("\nYou do a running jump!");
                                    System.out.println("You manage to pull yourself out!");
                                    System.out.println("You keep walking and there is a river.");
                                    System.out.println("\t[1] Jump across");
                                    System.out.println("\t[2] Try to swim");
                                    System.out.print(">");
                                    choice = Input.nextInt();
                                        if(choice == 1)
                                        {
                                            System.out.println("\nYou run as fast as you can and jump!");
                                            System.out.println("You barely made the jump.");
                                            System.out.println("You keep walking and see houses that were destroyed.");
                                            System.out.println("\t[1] Explore the houses");
                                            System.out.println("\t[2] Keep Going");
                                            System.out.print(">");
                                            choice = Input.nextInt();
                                                if(choice == 1)
                                                {
                                                    System.out.println("\nYou go inside the house.");
                                                    System.out.println("You look around to see if anybody is still here.");
                                                    System.out.println("You find some food on the table.");
                                                    System.out.println("\t[1] Eat");
                                                    System.out.println("\t[2] Don't eat");
                                                    System.out.print(">");
                                                    choice = Input.nextInt();
                                                        if(choice == 1)
                                                        {
                                                            System.out.println("\nYou eat the food.");
                                                            System.out.println("Hours later you feel pain in your stomach.");
                                                            System.out.println("You fall on the floor in pain.");
                                                            System.out.println("Press \"ENTER\" to continue..");
                                                            Input.nextLine();
                                                            Input.nextLine();
                                                            System.out.println("The food was poisoned.");
                                                            System.out.println("You are DEAD.");
                                                        }
                                                        else if(choice == 2)
                                                        {
                                                            System.out.println("\nYou don't eat the food.");
                                                            System.out.println("You keep searching the house for stuff.");
                                                            System.out.println("Press \"ENTER\" to continue..");
                                                            Input.nextLine();
                                                            Input.nextLine();
                                                            System.out.println("Suddenly you hear a loud crack on the roof.");
                                                            System.out.println("\t[1] Stay");
                                                            System.out.println("\t[2] Go outside");
                                                            System.out.print(">");
                                                            choice = Input.nextInt();
                                                                if(choice == 1)
                                                                {
                                                                    System.out.println("\nThe roof suddenly collapses!");
                                                                    System.out.println("You are DEAD!");
                                                                }
                                                                else if(choice == 2)
                                                                {
                                                                    System.out.println("\nYou go outside the house.");
                                                                    System.out.println("You keep walking.");
                                                                    System.out.println("You see a house.");
                                                                    System.out.println("You let go a sigh of relief...");
                                                                    System.out.println("Press \"ENTER\" to continue..");
                                                                    Input.nextLine();
                                                                    Input.nextLine();
                                                                    System.out.println("YOU MADE IT HOME!!!");
                                                                }
                                                        }
                                                }
                                                else if(choice == 2)
                                                {
                                                    System.out.println("\nYou keep walking for hours.");
                                                    System.out.println("Just when you are about to give up.");
                                                    System.out.println("You see a house.");
                                                    System.out.println("You let go a sigh of relief...");
                                                    System.out.println("Press \"ENTER\" to continue..");
                                                    Input.nextLine();
                                                    Input.nextLine();
                                                    System.out.println("YOU MADE IT HOME!!!");
                                                }
                                        }
                                        else if(choice == 2)
                                        {
                                            System.out.println("\nYou jump in the water.");
                                            System.out.println("You struggle to swim and stay afloat!");
                                            System.out.println("You are about to drown!");
                                            System.out.println("\t[1] Swim faster");
                                            System.out.println("\t[2] Grab a branch nearby");
                                            System.out.print(">");
                                            choice = Input.nextInt();
                                                if(choice == 1)
                                                {
                                                    System.out.println("\nYou try to swim faster,");
                                                    System.out.println("but the river current is too strong.");
                                                    System.out.println("You are DEAD.");
                                                }
                                                else if(choice == 2)
                                                {
                                                    System.out.println("\nYou grab a branch nearby and pull yourself up.");
                                                    System.out.println("You made it to the other side!");
                                                    System.out.println("You keep walking and see a house.");
                                                    System.out.println("\t[1] Explore");
                                                    System.out.println("\t[2] Keep going");
                                                    System.out.print(">");
                                                    choice = Input.nextInt();
                                                        if(choice == 1)
                                                        {
                                                            System.out.println("\nYou go inside the house.");
                                                            System.out.println("You take some food and water.");
                                                            System.out.println("Press \"ENTER\" to continue..");
                                                            Input.nextLine();
                                                            Input.nextLine();
                                                            System.out.println("Suddenly you hear cracking sounds.");
                                                            System.out.println("\t[1] Stay");
                                                            System.out.println("\t[2] Go outside");
                                                            System.out.print(">");
                                                            choice = Input.nextInt();
                                                                if(choice == 1)
                                                                {
                                                                    System.out.println("\nThe roof suddenly collapses!");
                                                                    System.out.println("You are DEAD!");
                                                                }
                                                                else if(choice == 2)
                                                                {
                                                                    System.out.println("\nYou run outside and the roof collapses.");
                                                                    System.out.println("You got out right on time!");
                                                                    System.out.println("You keep walking.");
                                                                    System.out.println("You let go a sigh of relief...");
                                                                    System.out.println("Press \"ENTER\" to continue..");
                                                                    Input.nextLine();
                                                                    Input.nextLine();
                                                                    System.out.println("YOU MADE IT HOME!!!");
                                                                }
                                                        }
                                                        else if(choice == 2)
                                                        {
                                                            System.out.println("\nYou keep walking for hours.");
                                                            System.out.println("Just when you are about to give up.");
                                                            System.out.println("You see a house.");
                                                            System.out.println("You let go a sigh of relief...");
                                                            System.out.println("Press \"ENTER\" to continue..");
                                                            Input.nextLine();
                                                            Input.nextLine();
                                                            System.out.println("YOU MADE IT HOME!!!");
                                                        }
                                                }
                                        }
                                }
                        }
                }
                //Walk
                else if(choice == 2)
                {
                    System.out.println("\nYou walk around and find a way across the ravine.");
                    System.out.println("You keep walking and see a river.");
                    System.out.println("The river is very deep...");
                    System.out.println("\t[1] Look around for an idea");
                    System.out.println("\t[2] Swim");
                    System.out.print(">");
                    choice = Input.nextInt();
                        if(choice == 1)
                        {
                            System.out.println("\nYou look around for materials.");
                            System.out.println("You find:");
                            System.out.println("- A broken raft");
                            System.out.println("- A long piece of wood");
                            System.out.println("- Aluminum sheet");
                            System.out.println("\t[1] Make a bridge");
                            System.out.println("\t[2] Fix the raft");
                            System.out.print(">");
                            choice = Input.nextInt();
                                if(choice == 1)
                                {
                                    System.out.println("\nYou make a wooden bridge.");
                                    System.out.println("You walk carefuly across to the other side.");
                                }
                                else if(choice == 2)
                                {
                                    System.out.println("You fix the raft.");
                                    System.out.println("You carefully paddle to the other side.");
                                }
                                System.out.println("You made it safely across!");
                                System.out.println("Press \"ENTER\" to continue..");
                                Input.nextLine();
                                Input.nextLine();
                                System.out.println("\nYou keep walking and see some ruined buildings.");
                                System.out.println("\t[1] Explore them");
                                System.out.println("\t[2] Keep going");
                                System.out.print(">");
                                choice = Input.nextInt();
                                    if(choice == 1)
                                    {
                                        System.out.println("\nYou see buildings that were once standing ruined.");
                                        System.out.println("You see one building that was not destroyed.");
                                        System.out.println("\t[1] Go inside");
                                        System.out.println("\t[2] Don't go");
                                        System.out.print(">");
                                        choice = Input.nextInt();
                                            if(choice == 1)
                                            {
                                                System.out.println("\nYou explore the building.");
                                                System.out.println("Concrete and debris were scattered everywhere.");
                                                System.out.println("Suddenly you hear a loud crack.");
                                                System.out.println("\t[1] Stay");
                                                System.out.println("\t[2] Go outside");
                                                System.out.print(">");
                                                choice = Input.nextInt();
                                                    if(choice == 1)
                                                    {
                                                        System.out.println("\nThe building suddenly collapses.");
                                                        System.out.println("You are crushed to death.");
                                                        System.out.println("You are DEAD.");
                                                    }
                                                    else if(choice == 2)
                                                    {
                                                        System.out.println("\nYou run outside and suddenly the building collapses.");
                                                        System.out.println("You run away from the dust.");
                                                        System.out.println("Suddenly you see a house in the distance.");
                                                        System.out.println("Press \"ENTER\" to continue..");
                                                        Input.nextLine();
                                                        Input.nextLine();
                                                        System.out.println("You run up to the house.");
                                                        System.out.println("YOU MADE IT HOME!!!");
                                                    }

                                            }
                                            else if(choice == 2)
                                            {
                                                System.out.println("\nYou keep walking.");
                                                System.out.println("You walk up to a house that was not destroyed.");
                                                System.out.println("You let go a sigh of relief...");
                                                System.out.println("Press \"ENTER\" to continue..");
                                                Input.nextLine();
                                                Input.nextLine();
                                                System.out.println("YOU MADE IT HOME!!!");
                                            }
                                    }
                                    else if(choice == 2)
                                    {
                                        System.out.println("\nYou keep walking for hours.");
                                        System.out.println("Just when you are about to give up.");
                                        System.out.println("You see a house.");
                                        System.out.println("You let go a sigh of relief...");
                                        System.out.println("Press \"ENTER\" to continue..");
                                        Input.nextLine();
                                        Input.nextLine();
                                        System.out.println("YOU MADE IT HOME!!!");
                                    }
                        }
                        else if(choice == 2)
                        {
                            System.out.println("\nYou jump in head first into the water.");
                            System.out.println("You start to swim but, the river is too strong.");
                            System.out.println("You are DEAD.");
                        }
                }
        }
        
        //River
        else if(choice == 2)
        {
            System.out.println("\nThere is a river you need to cross.");
            System.out.println("The river is deep and flowing fast.");
            System.out.println("What do you do?");
            System.out.println("\t[1] Look around for materials"); 
            System.out.println("\t[2] Try to swim");
            System.out.print(">");
            choice = Input.nextInt();
                if(choice == 1)
                {
                    System.out.println("\nYou look around for some materials.");
                    System.out.println("You find some wood and a broken raft.");
                    System.out.println("The river is flowing very fast.");
                    System.out.println("\t[1] Make a raft");
                    System.out.println("\t[2] Make a bridge");
                    System.out.print(">");
                    choice = Input.nextInt();
                        if(choice == 1)
                        {
                           System.out.println("\nYou make a raft.");
                           System.out.println("You paddle across the river.");                                            
                        }
                        else if(choice == 2)
                        {
                           System.out.println("\nYou make a bridge out of wood.");
                           System.out.println("You lay the plank across and walk carefully.");
                           
                        }
                        System.out.println("Press \"ENTER\" to continue..");
                        Input.nextLine();
                        Input.nextLine();
                        System.out.println("\nYou walk and see a lot of destruction.");
                        System.out.println("You see houses that were torn by the hurricane.");
                        System.out.println("\t[1] Explore the houses");
                        System.out.println("\t[2] Keep going");
                        System.out.print(">");
                        choice = Input.nextInt();
                            if(choice == 1)
                            {
                                System.out.println("\nYou walk toward the houses.");
                                System.out.println("Suddenly you hear a \"BARK\"!");
                                System.out.println("It's a dog!");
                                System.out.println("\t[1] Follow the dog");
                                System.out.println("\t[2] Don't follow");
                                System.out.print(">");
                                choice = Input.nextInt();
                                    if(choice == 1)
                                    {
                                        System.out.println("\nYou follow the dog.");
                                        System.out.println("The dog is fast and it's hard to keep up.");
                                        System.out.println("Suddenly the dog stops.");
                                        System.out.println("You smile with joy.");
                                        System.out.println("Press \"ENTER\" to continue..");
                                        Input.nextLine();
                                        Input.nextLine();
                                        System.out.println("YOU MADE IT HOME!!!");
                                    }
                                    else if(choice == 2)
                                    {
                                        System.out.println("\nYou pet the dog and keep going.");
                                        System.out.println("You walk for hours and hours.");
                                        System.out.println("When you were about to give up.");
                                        System.out.println("You see a familiar house.");
                                        System.out.println("Press \"ENTER\" to continue..");
                                        Input.nextLine();
                                        Input.nextLine();
                                        System.out.println("YOU MADE IT HOME!!!");
                                    }
                            }
                            else if(choice == 2)
                            {
                                System.out.println("\nYou keep walking, looking for your house.");
                                System.out.println("It's getting dark out.");
                                System.out.println("Suddenly a mountain lion runs at you!");
                                System.out.println("\t[1] Attack");
                                System.out.println("\t[2] Run");
                                System.out.print(">");
                                choice = Input.nextInt();
                                    if(choice == 1)
                                    {
                                        System.out.println("\nYou kill the mountain lion with your hands!");
                                        System.out.println("You keep walking and walking.");
                                        System.out.println("Finally you made it HOME!!");
                                    }
                                    else if(choice == 2)
                                    {
                                        System.out.println("\nThe mountain lion catches up and kills you.");
                                        System.out.println("You are DEAD.");
                                    }
                            }
                }
                else if(choice == 2)
                {
                    System.out.println("\nYou jump in head first into the water.");
                    System.out.println("You start to swim but, the river is too strong.");
                    System.out.println("You are DEAD.");
                }
        }
        
        //Forest
        else if(choice == 3)
        {
            System.out.println("\nYou got to the forest.");
            System.out.println("There is a bunch of trees and grass");
            System.out.println("You see a trail you can follow.");
            System.out.println("\t[1] Follow the trail");
            System.out.println("\t[2] Don't follow");
            System.out.print(">");
            choice = Input.nextInt();
                if(choice == 1)
                {
                    System.out.println("\nYou hear a howl.");
                    System.out.println("Then you see a wolf approaching.");
                    System.out.println("\t[1] Hide");
                    System.out.println("\t[2] Run");
                    System.out.print(">");
                    choice = Input.nextInt();
                        if(choice == 1)
                        {
                            System.out.println("\nYou have escaped!");
                            System.out.println("You come across a river.");
                            System.out.println("It's shallow but has a lot of rocks");
                            System.out.println("\t[1] Try to jump across");
                            System.out.println("\t[2] Try to swim");
                            System.out.print(">");
                            choice = Input.nextInt();
                                if(choice == 1)
                                {
                                    System.out.println("\nYou jump in head first into the water.");
                                    System.out.println("You bang your head on a rock.");
                                    System.out.println("You are DEAD.");
                                }
                                else if(choice == 2)
                                {
                                    System.out.println("\nYou swim carefully to the other side.");
                                    System.out.println("You made it across!");
                                    System.out.println("You see many houses that are demolished.");
                                    System.out.println("\t[1] Explore them");
                                    System.out.println("\t[2] Keep going");
                                    System.out.print(">");
                                    choice = Input.nextInt();
                                        if(choice == 1)
                                        {
                                            System.out.println("\nYou explore the building.");
                                            System.out.println("Concrete and debris were scattered everywhere.");
                                            System.out.println("Suddenly you hear a loud crack.");
                                            System.out.println("\t[1] Stay");
                                            System.out.println("\t[2] Go outside");
                                            System.out.print(">");
                                            choice = Input.nextInt();
                                               if(choice == 1)
                                               {
                                                   System.out.println("\nThe building suddenly collapses.");
                                                   System.out.println("You are crushed to death.");
                                                   System.out.println("You are DEAD.");
                                                }
                                                else if(choice == 2)
                                                {
                                                    System.out.println("You come across another house.");  
                                                    System.out.println("\t[1] Explore");
                                                    System.out.println("\t[2] Keep going");
                                                    System.out.print(">");
                                                    choice = Input.nextInt();
                                                        if(choice == 1)
                                                        {
                                                            System.out.println("\nYou go inside the house.");
                                                            System.out.println("You hear something in the basement.");
                                                            System.out.println("\t[1] Go look");
                                                            System.out.println("\t[2] Keep going");
                                                            System.out.print(">");
                                                            choice = Input.nextInt();
                                                                if(choice == 1)
                                                                {
                                                                    System.out.println("\nYou slowly go downstairs.");
                                                                    System.out.println("You have a funny feeling.");
                                                                    System.out.println("Press \"ENTER\" to continue..");
                                                                    Input.nextLine();
                                                                    Input.nextLine();
                                                                    System.out.println("Suddenly you see a black figure.");
                                                                    System.out.println("\t[1] Run");
                                                                    System.out.println("\t[2] Keep going");
                                                                    System.out.print(">");
                                                                    choice = Input.nextInt();
                                                                        if(choice == 1)
                                                                        {
                                                                            System.out.println("\nYou sprint outside.");
                                                                            System.out.println("You run as far as your feet can take you.");
                                                                            System.out.println("You stop to rest.");
                                                                            System.out.println("You see a familiar house.");
                                                                            System.out.println("Press \"ENTER\" to continue..");
                                                                            Input.nextLine();
                                                                            Input.nextLine();
                                                                            System.out.println("YOU MADE IT HOME!!!");
                                                                        }
                                                                        else if(choice == 2)
                                                                        {
                                                                            System.out.println("\nYou encounter a person.");
                                                                            System.out.println("It was a person who survived the hurricane.");
                                                                            System.out.println("He goes outside and leads you to a house.");
                                                                            System.out.println("Press \"ENTER\" to continue..");
                                                                            Input.nextLine();
                                                                            Input.nextLine();
                                                                            System.out.println("YOU MADE IT HOME!!!");
                                                                        }

                                                                }
                                                                else if(choice == 2)
                                                                {
                                                                    System.out.println("\nYou walk out of the house.");
                                                                    System.out.println("You walk for hours and hours.");
                                                                    System.out.println("Suddenly you see a familiar house.");
                                                                    System.out.println("Press \"ENTER\" to continue..");
                                                                    Input.nextLine();
                                                                    Input.nextLine();
                                                                    System.out.println("YOU MADE IT HOME!!!");
                                                                }
                                                        }
                                                        else if(choice == 2)
                                                        {
                                                            System.out.println("\nYou keep walking.");
                                                            System.out.println("You walk for hours and hours.");
                                                            System.out.println("When you were about to give up.");
                                                            System.out.println("You see a familiar house.");
                                                            System.out.println("Press \"ENTER\" to continue..");
                                                            Input.nextLine();
                                                            Input.nextLine();
                                                            System.out.println("YOU MADE IT HOME!!!");
                                                        }
                                                }
                                        }
                                        else if(choice == 2)
                                        {
                                            System.out.println("\nYou keep walking.");
                                            System.out.println("You walk for hours and hours.");
                                            System.out.println("When you were about to give up.");
                                            System.out.println("You see a familiar house.");
                                            System.out.println("Press \"ENTER\" to continue..");
                                            Input.nextLine();
                                            Input.nextLine();
                                            System.out.println("YOU MADE IT HOME!!!");
                                        }
                                }
                        }
                        else if(choice == 2)
                        {
                            System.out.println("\nThe wolf starts chasing after you.");
                            System.out.println("It's catching up!");
                            System.out.println("\t[1] Run faster");
                            System.out.println("\t[2] Roll and hide");
                            System.out.print(">");
                            choice = Input.nextInt();
                                if(choice == 1)
                                {
                                    System.out.println("\nThe wolf catches up and kills you.");
                                    System.out.println("You are DEAD.");
                                }
                                else if(choice == 2)
                                {
                                    System.out.println("\nYou quickly roll into the bushes.");
                                    int answer = random.nextInt(100)+ 1;

                                        if(answer > 50)
                                        {
                                            System.out.println("\nYou manage to escape the wolf!");
                                            System.out.println("You keep walking and see a house.");
                                            System.out.println("Press \"ENTER\" to continue");
                                            Input.nextLine();
                                            Input.nextLine();
                                            System.out.println("YOU MADE IT HOME!!!");
                                            
                                        }
                                        else if(answer < 50)
                                        {
                                            System.out.println("\nThe wolf smells you hiding.");
                                            System.out.println("It lunges into the bushes.");
                                            System.out.println("You are DEAD.");
                                        }

                                }
                        }
                }
                else if(choice == 2)
                {
                    System.out.println("\nYou go off path and see a cave.");
                    System.out.println("The cave seems to be pretty deep.");
                    System.out.println("There might be nice jewels?");
                    System.out.println("\t[1] Go in");
                    System.out.println("\t[2] Don't go");
                    System.out.print(">");
                    choice = Input.nextInt();
                        if(choice == 1)
                        {
                            System.out.println("\nYou enter the cave.");
                            System.out.println("Press \"ENTER\" to continue");
                            Input.nextLine();
                            Input.nextLine();
                            System.out.println("It's very dark and the ground is uneven.");
                            System.out.println("You keep walking and see a pool of water.");
                            System.out.println("\t[1] Keep going");
                            System.out.println("\t[2] Jump in");
                            System.out.print(">");
                            choice = Input.nextInt();
                                if(choice == 1)
                                {
                                    System.out.println("\nYou keep walking. You realize you are lost.");
                                    System.out.println("You see many bats in the cave flying around.");
                                    System.out.println("You suddenly feel very sleepy.");
                                    System.out.println("\t[1] Sleep");
                                    System.out.println("\t[2] Keep going");
                                    System.out.print(">");
                                    choice = Input.nextInt();
                                        if(choice == 1)
                                        { 
                                            System.out.println("\nYou take a quick nap.");
                                            System.out.println("Press \"ENTER\" to continue");
                                            Input.nextLine();
                                            Input.nextLine();
                                            System.out.println("You wake up and it is pitch black.");
                                            System.out.println("You can't see anything.");
                                            System.out.println("\t[1] Look for light");
                                            System.out.println("\t[2] Try to run");
                                            System.out.print(">");
                                            choice = Input.nextInt();
                                                if(choice == 1)
                                                {
                                                    System.out.println("\nYou keep walking slowly and see light.");
                                                    System.out.println("You made it outside!");
                                                    System.out.println("You keep walking and see some houses.");
                                                    System.out.println("\t[1] Explore");
                                                    System.out.println("\t[2] Keep going");
                                                    System.out.print(">");
                                                    choice = Input.nextInt();
                                                        if(choice == 1)
                                                        {
                                                            System.out.println("\nYou go inside one of the houses.");
                                                            System.out.println("Inside the house there is a weird sound.");
                                                            System.out.println("You hear some cracking on the roof.");
                                                            System.out.println("\t[1] Stay");
                                                            System.out.println("\t[2] Go outside");
                                                            System.out.print(">");
                                                            choice = Input.nextInt();
                                                                if(choice == 1)
                                                                {
                                                                    System.out.println("\nThe roof suddenly rumbles...");
                                                                    System.out.println("Press \"ENTER\" to continue..");
                                                                    Input.nextLine();
                                                                    Input.nextLine();
                                                                    System.out.println("BOOM!");
                                                                    System.out.println("The roof gave in and collapses.");
                                                                    System.out.println("You are DEAD.");
                                                                }
                                                                else if(choice == 2)
                                                                {
                                                                    System.out.println("\nYou walk back outside");
                                                                    System.out.println("You walk for hours and hours.");
                                                                    System.out.println("When you were about to give up.");
                                                                    System.out.println("You see a familiar house.");
                                                                    System.out.println("Press \"ENTER\" to continue..");
                                                                    Input.nextLine();
                                                                    Input.nextLine();
                                                                    System.out.println("YOU MADE IT HOME!!!");
                                                                }
                                                        }
                                                        else if(choice == 2)
                                                        {
                                                            System.out.println("You keep walking and see something.");
                                                            System.out.println("You see a familiar house.");
                                                            System.out.println("Press \"ENTER\" to continue..");
                                                            Input.nextLine();
                                                            Input.nextLine();
                                                            System.out.println("YOU MADE IT HOME!!!");
                                                        }
                                                }
                                                else if(choice == 2)
                                                {
                                                    System.out.println("\nYou run forward.");
                                                    System.out.println("\nYou hit your head against the rock wall.");
                                                    System.out.println("You are DEAD.");
                                                }
                                        }
                                        else if(choice == 2)
                                        {
                                            System.out.println("\nYou keep going and finally you see some light. ");
                                            System.out.println("Press \"ENTER\" to continue");
                                            Input.nextLine();
                                            Input.nextLine();
                                            System.out.println("You made it outside and you can see your whole town.");
                                            System.out.println("Suddenly you spot a familiar house.");
                                            System.out.println("You are HOME!");
                                        }

                                }
                                else if(choice == 2)
                                {
                                    System.out.println("\nYou jump in the pool of water.");
                                    System.out.println("Suddenly you go deeper underwater.");
                                    System.out.println("Then silence......");
                                    System.out.println("You are DEAD");
                                }
                        }
                        else if(choice == 2)
                        {
                            System.out.println("\nYou keep walking a see a river.");
                            System.out.println("You need to get across.");
                            System.out.println("\t[1] Think");
                            System.out.println("\t[2] Swim");
                            System.out.print(">");
                            choice = Input.nextInt();
                                if(choice == 1)
                                {
                                    System.out.println("\nYou look around for some materials.");
                                    System.out.println("You find some wood and a broken raft.");
                                    System.out.println("The river is flowing very fast.");
                                    System.out.println("\t[1] Make a raft");
                                    System.out.println("\t[2] Make a bridge");
                                    System.out.print(">");
                                    choice = Input.nextInt();
                                    if(choice == 1)
                                        {
                                            System.out.println("\nYou make a raft.");
                                            System.out.println("You paddle across the river.");                                            
                                        }
                                        else if(choice == 2)
                                        {
                                            System.out.println("\nYou make a bridge out of wood.");
                                            System.out.println("You lay the plank across and walk carefully.");
                                        }
                                }
                                else if(choice == 2)
                                {
                                    System.out.println("\nThe current is too fast!");
                                    System.out.println("You blackout and wake up. You are alive!");
                                }
                                System.out.println("You made it across!");
                                System.out.println("Press \"ENTER\" to continue");
                                Input.nextLine();
                                Input.nextLine();
                                System.out.println("You keep walking and see houses that were destroyed.");
                                System.out.println("You go in the house and see some food and broken furniture.");
                                System.out.println("Suddenly you hear cracking sounds.");
                                System.out.println("\t[1] Stay");
                                System.out.println("\t[2] Go outside");
                                System.out.print(">");
                                choice = Input.nextInt();
                                if(choice == 1)
                                {
                                    System.out.println("The roof collapses.");
                                    System.out.println("You are DEAD.");
                                }
                                else if(choice == 2)
                                {
                                    System.out.println("You run outside.");
                                    System.out.println("Suddenly the roof collapses.");
                                    System.out.println("You are lucky that you survived!");
                                    System.out.println("You keep walking and see a house.");
                                    System.out.println("Press \"ENTER\" to continue");
                                    Input.nextLine();
                                    Input.nextLine();
                                    System.out.println("YOU MADE IT HOME!!!");
                                }                     
                        }
                }
        }
                                System.out.println("Would you like to play again? (y/n)");
                                System.out.print(">");                         
                                playAgain = Input.nextLine();
                                playAgain = Input.nextLine();                                
                                if (playAgain.equalsIgnoreCase("Yes") || playAgain.equalsIgnoreCase("Y"))
                                {
                                        gameRunning = true;
                                }
                                else if (playAgain.equalsIgnoreCase("No") || playAgain.equalsIgnoreCase("N"))
                                {
                                        gameRunning = false;
                                        System.out.println("Thanks for playing!");
                                }
        }
    }    
}
